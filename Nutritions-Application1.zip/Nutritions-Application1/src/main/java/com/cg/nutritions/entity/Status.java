package com.cg.nutritions.entity;

import org.springframework.stereotype.Component;


public enum Status {

	BlOCKED,ACTIVE
}
